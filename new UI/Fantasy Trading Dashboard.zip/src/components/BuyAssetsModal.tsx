import { useState, useEffect } from 'react';
import { X, Search, TrendingUp, TrendingDown, DollarSign, Info, AlertCircle, CheckCircle } from 'lucide-react';

interface BuyAssetsModalProps {
  isOpen: boolean;
  onClose: () => void;
  tradeRoom: any;
  availableCash: number;
}

interface Asset {
  symbol: string;
  name: string;
  type: string;
  currentPrice: number;
  change: number;
  changePercent: number;
  volume: string;
  marketCap: string;
  dayHigh: number;
  dayLow: number;
  description: string;
}

export function BuyAssetsModal({ isOpen, onClose, tradeRoom, availableCash }: BuyAssetsModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [quantity, setQuantity] = useState<number>(1);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market');
  const [limitPrice, setLimitPrice] = useState<string>('');

  // Mock assets based on trade room type
  const allAssets: Asset[] = [
    {
      symbol: 'AAPL',
      name: 'Apple Inc.',
      type: 'Stock',
      currentPrice: 185.20,
      change: 3.45,
      changePercent: 1.90,
      volume: '52.3M',
      marketCap: '$2.89T',
      dayHigh: 186.50,
      dayLow: 183.20,
      description: 'Technology company that designs and manufactures consumer electronics and software.'
    },
    {
      symbol: 'GOOGL',
      name: 'Alphabet Inc.',
      type: 'Stock',
      currentPrice: 148.90,
      change: 2.15,
      changePercent: 1.47,
      volume: '28.7M',
      marketCap: '$1.87T',
      dayHigh: 149.80,
      dayLow: 147.30,
      description: 'Multinational technology company specializing in Internet services and products.'
    },
    {
      symbol: 'MSFT',
      name: 'Microsoft Corp.',
      type: 'Stock',
      currentPrice: 368.75,
      change: -1.25,
      changePercent: -0.34,
      volume: '21.4M',
      marketCap: '$2.74T',
      dayHigh: 371.20,
      dayLow: 367.50,
      description: 'Technology corporation that develops computer software and consumer electronics.'
    },
    {
      symbol: 'TSLA',
      name: 'Tesla Inc.',
      type: 'Stock',
      currentPrice: 258.30,
      change: 12.80,
      changePercent: 5.21,
      volume: '145.2M',
      marketCap: '$820B',
      dayHigh: 260.40,
      dayLow: 252.10,
      description: 'Electric vehicle and clean energy company.'
    },
    {
      symbol: 'NVDA',
      name: 'NVIDIA Corp.',
      type: 'Stock',
      currentPrice: 498.60,
      change: 8.90,
      changePercent: 1.82,
      volume: '42.1M',
      marketCap: '$1.23T',
      dayHigh: 502.30,
      dayLow: 495.20,
      description: 'Technology company that designs graphics processing units for gaming and professional markets.'
    },
    {
      symbol: 'AMZN',
      name: 'Amazon.com Inc.',
      type: 'Stock',
      currentPrice: 178.45,
      change: 2.35,
      changePercent: 1.33,
      volume: '38.6M',
      marketCap: '$1.85T',
      dayHigh: 179.80,
      dayLow: 176.90,
      description: 'E-commerce and cloud computing company.'
    },
    {
      symbol: 'META',
      name: 'Meta Platforms Inc.',
      type: 'Stock',
      currentPrice: 485.30,
      change: 6.75,
      changePercent: 1.41,
      volume: '15.8M',
      marketCap: '$1.24T',
      dayHigh: 488.20,
      dayLow: 481.50,
      description: 'Social media and technology conglomerate.'
    },
    {
      symbol: 'BTC-USD',
      name: 'Bitcoin',
      type: 'Cryptocurrency',
      currentPrice: 42350.00,
      change: 1250.00,
      changePercent: 3.04,
      volume: '$28.5B',
      marketCap: '$830B',
      dayHigh: 42850.00,
      dayLow: 41200.00,
      description: 'Decentralized digital currency without a central bank or single administrator.'
    },
    {
      symbol: 'ETH-USD',
      name: 'Ethereum',
      type: 'Cryptocurrency',
      currentPrice: 2240.50,
      change: 85.30,
      changePercent: 3.96,
      volume: '$15.2B',
      marketCap: '$269B',
      dayHigh: 2265.00,
      dayLow: 2180.00,
      description: 'Decentralized platform for smart contracts and decentralized applications.'
    },
    {
      symbol: 'AAPL250117C00190000',
      name: 'AAPL Jan 17 2025 $190 Call',
      type: 'Option',
      currentPrice: 8.50,
      change: 0.75,
      changePercent: 9.68,
      volume: '12.4K',
      marketCap: 'N/A',
      dayHigh: 8.80,
      dayLow: 7.90,
      description: 'Call option for Apple Inc. with strike price $190, expiring January 17, 2025.'
    }
  ];

  const filteredAssets = allAssets.filter(asset =>
    asset.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    asset.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalCost = selectedAsset ? selectedAsset.currentPrice * quantity : 0;
  const estimatedFees = totalCost * 0.001; // 0.1% fee
  const totalWithFees = totalCost + estimatedFees;
  const remainingCash = availableCash - totalWithFees;
  const canAfford = remainingCash >= 0;

  const handleSelectAsset = (asset: Asset) => {
    setSelectedAsset(asset);
    setSearchQuery(asset.symbol);
    setShowSuggestions(false);
    setLimitPrice(asset.currentPrice.toFixed(2));
  };

  const handleBuy = () => {
    if (!selectedAsset || !canAfford) return;
    console.log('Buying:', { asset: selectedAsset, quantity, orderType, totalWithFees });
    // Handle buy logic here
    onClose();
  };

  useEffect(() => {
    if (searchQuery && !selectedAsset) {
      setShowSuggestions(true);
    }
  }, [searchQuery, selectedAsset]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative w-full max-w-2xl bg-slate-800 rounded-2xl border border-slate-700 shadow-2xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <div>
            <h2 className="text-white mb-1">Buy Assets</h2>
            <p className="text-slate-400 text-sm">{tradeRoom.name}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            {/* Search */}
            <div>
              <label className="block text-slate-300 mb-2">Search Asset</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by symbol or name..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setSelectedAsset(null);
                  }}
                  onFocus={() => setShowSuggestions(true)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                />

                {/* Suggestions Dropdown */}
                {showSuggestions && filteredAssets.length > 0 && !selectedAsset && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-h-80 overflow-y-auto z-10">
                    {filteredAssets.map((asset) => (
                      <button
                        key={asset.symbol}
                        onClick={() => handleSelectAsset(asset)}
                        className="w-full p-4 hover:bg-slate-800 transition-colors text-left border-b border-slate-700/50 last:border-b-0"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="text-white">{asset.symbol}</p>
                              <span className="px-2 py-0.5 bg-slate-700 text-slate-300 rounded text-xs">
                                {asset.type}
                              </span>
                            </div>
                            <p className="text-slate-400 text-sm">{asset.name}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-white">${asset.currentPrice.toLocaleString()}</p>
                            <div className={`flex items-center gap-1 text-sm ${
                              asset.changePercent >= 0 ? 'text-green-400' : 'text-red-400'
                            }`}>
                              {asset.changePercent >= 0 ? (
                                <TrendingUp className="w-3 h-3" />
                              ) : (
                                <TrendingDown className="w-3 h-3" />
                              )}
                              <span>{asset.changePercent >= 0 ? '+' : ''}{asset.changePercent}%</span>
                            </div>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Selected Asset Full Details */}
            {selectedAsset && (
              <>
                {/* Asset Header */}
                <div className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border border-purple-500/30 rounded-xl p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-white text-2xl">{selectedAsset.symbol}</h3>
                        <span className="px-2 py-1 bg-purple-500/20 text-purple-300 rounded text-sm">
                          {selectedAsset.type}
                        </span>
                      </div>
                      <p className="text-slate-300">{selectedAsset.name}</p>
                    </div>
                    <button
                      onClick={() => {
                        setSelectedAsset(null);
                        setSearchQuery('');
                      }}
                      className="text-slate-400 hover:text-white text-sm"
                    >
                      Change
                    </button>
                  </div>

                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-slate-400 text-sm mb-1">Current Price</p>
                      <p className="text-white text-3xl">${selectedAsset.currentPrice.toLocaleString()}</p>
                    </div>
                    <div className={`flex items-center gap-2 ${
                      selectedAsset.changePercent >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {selectedAsset.changePercent >= 0 ? (
                        <TrendingUp className="w-5 h-5" />
                      ) : (
                        <TrendingDown className="w-5 h-5" />
                      )}
                      <div className="text-right">
                        <p className="text-xl">{selectedAsset.changePercent >= 0 ? '+' : ''}{selectedAsset.changePercent}%</p>
                        <p className="text-sm">{selectedAsset.changePercent >= 0 ? '+' : ''}${selectedAsset.change}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Market Info */}
                <div className="bg-slate-900/50 border border-slate-700 rounded-xl p-4">
                  <p className="text-slate-400 text-sm mb-3">Market Information</p>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-slate-400 text-xs mb-1">Day High</p>
                      <p className="text-white">${selectedAsset.dayHigh}</p>
                    </div>
                    <div>
                      <p className="text-slate-400 text-xs mb-1">Day Low</p>
                      <p className="text-white">${selectedAsset.dayLow}</p>
                    </div>
                    <div>
                      <p className="text-slate-400 text-xs mb-1">Volume</p>
                      <p className="text-white">{selectedAsset.volume}</p>
                    </div>
                    <div>
                      <p className="text-slate-400 text-xs mb-1">Market Cap</p>
                      <p className="text-white">{selectedAsset.marketCap}</p>
                    </div>
                  </div>
                </div>

                {/* Order Type */}
                <div>
                  <label className="block text-slate-300 mb-2">Order Type</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setOrderType('market')}
                      className={`py-3 px-4 rounded-xl border transition-all ${
                        orderType === 'market'
                          ? 'bg-purple-500/20 border-purple-500 text-white'
                          : 'bg-slate-900/50 border-slate-700 text-slate-400 hover:border-slate-600'
                      }`}
                    >
                      <p className="text-sm">Market Order</p>
                      <p className="text-xs opacity-70 mt-1">Execute immediately</p>
                    </button>
                    <button
                      onClick={() => setOrderType('limit')}
                      className={`py-3 px-4 rounded-xl border transition-all ${
                        orderType === 'limit'
                          ? 'bg-purple-500/20 border-purple-500 text-white'
                          : 'bg-slate-900/50 border-slate-700 text-slate-400 hover:border-slate-600'
                      }`}
                    >
                      <p className="text-sm">Limit Order</p>
                      <p className="text-xs opacity-70 mt-1">Set your price</p>
                    </button>
                  </div>
                </div>

                {/* Limit Price */}
                {orderType === 'limit' && (
                  <div>
                    <label className="block text-slate-300 mb-2">Limit Price</label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                      <input
                        type="number"
                        step="0.01"
                        value={limitPrice}
                        onChange={(e) => setLimitPrice(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                      />
                    </div>
                    <p className="text-slate-400 text-xs mt-2">
                      Current market price: ${selectedAsset.currentPrice}
                    </p>
                  </div>
                )}

                {/* Quantity */}
                <div>
                  <label className="block text-slate-300 mb-2">Number of Shares</label>
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-xl text-white text-xl placeholder-slate-400 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20"
                  />
                  <div className="flex gap-2 mt-3">
                    {[1, 5, 10, 25, 50, 100].map((val) => (
                      <button
                        key={val}
                        onClick={() => setQuantity(val)}
                        className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-lg text-sm transition-colors"
                      >
                        {val}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Order Summary */}
                <div className="bg-slate-900/50 border border-slate-700 rounded-xl p-5">
                  <h3 className="text-white mb-4">Order Summary</h3>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">{quantity} shares × ${selectedAsset.currentPrice.toLocaleString()}</span>
                      <span className="text-white">${totalCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-1">
                        <span className="text-slate-400">Trading Fee (0.1%)</span>
                        <Info className="w-3 h-3 text-slate-500" />
                      </div>
                      <span className="text-white">${estimatedFees.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </div>
                    <div className="h-px bg-slate-700 my-2" />
                    <div className="flex items-center justify-between">
                      <span className="text-white">Total Cost</span>
                      <span className="text-white text-2xl">${totalWithFees.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </div>
                  </div>
                </div>

                {/* Available Cash Status */}
                <div className={`border rounded-xl p-4 ${
                  canAfford 
                    ? 'bg-green-500/10 border-green-500/30' 
                    : 'bg-red-500/10 border-red-500/30'
                }`}>
                  <div className="flex items-start gap-3">
                    {canAfford ? (
                      <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                    )}
                    <div className="flex-1">
                      <p className={`mb-3 ${canAfford ? 'text-green-400' : 'text-red-400'}`}>
                        {canAfford ? 'Sufficient funds available' : 'Insufficient funds'}
                      </p>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-slate-400 mb-1">Available Cash</p>
                          <p className="text-white text-lg">${availableCash.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-slate-400 mb-1">Remaining After Purchase</p>
                          <p className={`text-lg ${canAfford ? 'text-white' : 'text-red-400'}`}>
                            ${remainingCash.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    onClick={onClose}
                    className="py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleBuy}
                    disabled={!canAfford}
                    className={`py-3 rounded-xl transition-colors ${
                      canAfford
                        ? 'bg-green-600 hover:bg-green-700 text-white'
                        : 'bg-slate-700 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    Place Buy Order
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}