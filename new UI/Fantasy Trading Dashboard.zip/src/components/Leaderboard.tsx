import { Trophy, TrendingUp, Medal, Crown } from 'lucide-react';

interface LeaderboardProps {
  tradeRoom: any;
}

export function Leaderboard({ tradeRoom }: LeaderboardProps) {
  const players = [
    {
      rank: 1,
      name: 'Sarah Chen',
      username: '@sarach',
      portfolio: 28450,
      change: 12.5,
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      isYou: false
    },
    {
      rank: 2,
      name: 'Mike Johnson',
      username: '@mikej',
      portfolio: 26780,
      change: 9.8,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      isYou: false
    },
    {
      rank: 3,
      name: 'Alex Morgan',
      username: '@alexm_trader',
      portfolio: 24780,
      change: 5.2,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop',
      isYou: true
    },
    {
      rank: 4,
      name: 'Emma Wilson',
      username: '@emmaw',
      portfolio: 23540,
      change: 8.1,
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
      isYou: false
    },
    {
      rank: 5,
      name: 'David Lee',
      username: '@davidl',
      portfolio: 22890,
      change: 6.7,
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      isYou: false
    },
    {
      rank: 6,
      name: 'Lisa Park',
      username: '@lisap',
      portfolio: 21450,
      change: 4.2,
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop',
      isYou: false
    },
    {
      rank: 7,
      name: 'James Smith',
      username: '@jamesm',
      portfolio: 20120,
      change: 3.8,
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop',
      isYou: false
    },
    {
      rank: 8,
      name: 'Nina Patel',
      username: '@ninap',
      portfolio: 19670,
      change: -1.2,
      avatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop',
      isYou: false
    }
  ];

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="w-5 h-5 text-yellow-400" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-slate-300" />;
    if (rank === 3) return <Medal className="w-5 h-5 text-orange-400" />;
    return <span className="text-slate-400">{rank}</span>;
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return 'bg-yellow-500/10 border-yellow-500/30';
    if (rank === 2) return 'bg-slate-500/10 border-slate-500/30';
    if (rank === 3) return 'bg-orange-500/10 border-orange-500/30';
    return 'bg-slate-900/30 border-slate-700/30';
  };

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50 sticky top-24">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-yellow-500/20 rounded-lg">
          <Trophy className="w-5 h-5 text-yellow-400" />
        </div>
        <div>
          <h2 className="text-white">Leaderboard</h2>
          <p className="text-slate-400 text-sm">{tradeRoom.players} players competing</p>
        </div>
      </div>

      {/* Prize Distribution */}
      <div className="bg-gradient-to-r from-yellow-500/10 to-purple-500/10 border border-yellow-500/30 rounded-xl p-4 mb-6">
        <p className="text-slate-400 text-sm mb-2">Prize Distribution</p>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Crown className="w-4 h-4 text-yellow-400" />
              <span className="text-white text-sm">1st Place</span>
            </div>
            <span className="text-yellow-400">${(tradeRoom.prize * 0.5).toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Medal className="w-4 h-4 text-slate-300" />
              <span className="text-white text-sm">2nd Place</span>
            </div>
            <span className="text-slate-300">${(tradeRoom.prize * 0.3).toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Medal className="w-4 h-4 text-orange-400" />
              <span className="text-white text-sm">3rd Place</span>
            </div>
            <span className="text-orange-400">${(tradeRoom.prize * 0.2).toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Players List */}
      <div className="space-y-2 max-h-[500px] overflow-y-auto">
        {players.map((player) => (
          <div
            key={player.rank}
            className={`rounded-xl p-3 border transition-all ${
              player.isYou 
                ? 'bg-purple-500/20 border-purple-500/50 ring-2 ring-purple-500/30' 
                : getRankColor(player.rank)
            }`}
          >
            <div className="flex items-center gap-3">
              {/* Rank */}
              <div className="w-8 flex items-center justify-center">
                {getRankIcon(player.rank)}
              </div>

              {/* Avatar */}
              <img
                src={player.avatar}
                alt={player.name}
                className="w-10 h-10 rounded-full object-cover"
              />

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-white text-sm">{player.name}</p>
                  {player.isYou && (
                    <span className="px-2 py-0.5 bg-purple-500/30 text-purple-300 rounded text-xs">
                      You
                    </span>
                  )}
                </div>
                <p className="text-slate-400 text-xs">{player.username}</p>
              </div>

              {/* Stats */}
              <div className="text-right">
                <p className="text-white text-sm">${player.portfolio.toLocaleString()}</p>
                <div className={`flex items-center justify-end gap-1 text-xs ${
                  player.change >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                  <TrendingUp className={`w-3 h-3 ${player.change < 0 ? 'rotate-180' : ''}`} />
                  <span>{player.change >= 0 ? '+' : ''}{player.change}%</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Your Stats Summary */}
      <div className="mt-4 pt-4 border-t border-slate-700/50">
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-900/50 rounded-lg p-3">
            <p className="text-slate-400 text-xs mb-1">Your Rank</p>
            <p className="text-purple-400 text-xl">#{tradeRoom.position}</p>
          </div>
          <div className="bg-slate-900/50 rounded-lg p-3">
            <p className="text-slate-400 text-xs mb-1">To Lead</p>
            <p className="text-white text-xl">$3,670</p>
          </div>
        </div>
      </div>
    </div>
  );
}
