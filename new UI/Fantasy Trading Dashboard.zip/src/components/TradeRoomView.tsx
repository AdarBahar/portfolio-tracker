import { ArrowLeft } from 'lucide-react';
import { TradeRoomSummary } from './TradeRoomSummary';
import { Portfolio } from './Portfolio';
import { AIRecommendations } from './AIRecommendations';
import { Leaderboard } from './Leaderboard';

interface TradeRoomViewProps {
  tradeRoom: any;
  onBack: () => void;
}

export function TradeRoomView({ tradeRoom, onBack }: TradeRoomViewProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Dashboard</span>
        </button>

        {/* Trade Room Title */}
        <div className="mb-6">
          <h1 className="text-white mb-2">{tradeRoom.name}</h1>
          <p className="text-slate-400">{tradeRoom.type}</p>
        </div>

        {/* Summary Line */}
        <TradeRoomSummary tradeRoom={tradeRoom} />

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Portfolio & AI Recommendations */}
          <div className="lg:col-span-2 space-y-6">
            <Portfolio tradeRoom={tradeRoom} />
            <AIRecommendations />
          </div>

          {/* Right Column - Leaderboard */}
          <div className="lg:col-span-1">
            <Leaderboard tradeRoom={tradeRoom} />
          </div>
        </div>
      </div>
    </div>
  );
}
