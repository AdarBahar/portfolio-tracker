import { GameCard } from './GameCard';
import { Gamepad2 } from 'lucide-react';

interface CurrentGamesProps {
  searchQuery: string;
  onSelectRoom: (room: any) => void;
}

export function CurrentGames({ searchQuery, onSelectRoom }: CurrentGamesProps) {
  const currentGames = [
    {
      id: 1,
      name: 'Tech Giants League',
      type: 'Stock Trading',
      players: 12,
      maxPlayers: 12,
      prize: 5000,
      position: 3,
      endDate: '2025-11-30',
      status: 'active',
      portfolio: 12450
    },
    {
      id: 2,
      name: 'Crypto Masters',
      type: 'Cryptocurrency',
      players: 8,
      maxPlayers: 10,
      prize: 10000,
      position: 1,
      endDate: '2025-12-05',
      status: 'active',
      portfolio: 24780
    },
    {
      id: 3,
      name: 'Daily Sprint',
      type: 'Day Trading',
      players: 50,
      maxPlayers: 50,
      prize: 2500,
      position: 15,
      endDate: '2025-11-26',
      status: 'ending-soon',
      portfolio: 8230
    }
  ];

  const filteredGames = currentGames.filter(game =>
    game.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    game.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="mb-8">
      <div className="flex items-center gap-3 mb-4">
        <Gamepad2 className="w-6 h-6 text-purple-400" />
        <h2 className="text-white">Your Active Trade Rooms</h2>
        <span className="px-3 py-1 bg-purple-500/20 text-purple-300 rounded-full text-sm">
          {filteredGames.length}
        </span>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredGames.map(game => (
          <GameCard key={game.id} game={game} isActive={true} onSelect={onSelectRoom} />
        ))}
      </div>
    </div>
  );
}