import { Sparkles, TrendingUp, AlertCircle, CheckCircle, Clock } from 'lucide-react';

export function AIRecommendations() {
  const recommendations = [
    {
      type: 'buy',
      symbol: 'NVDA',
      name: 'NVIDIA Corp.',
      confidence: 85,
      reason: 'Strong momentum in AI sector. Technical indicators show bullish pattern. Analyst upgrades increasing.',
      targetPrice: 525,
      currentPrice: 498.60,
      potentialGain: 5.3,
      timestamp: '2 minutes ago'
    },
    {
      type: 'sell',
      symbol: 'MSFT',
      name: 'Microsoft Corp.',
      confidence: 72,
      reason: 'Overbought conditions detected. Resistance at current levels. Consider profit-taking.',
      targetPrice: 355,
      currentPrice: 368.75,
      potentialLoss: -3.7,
      timestamp: '15 minutes ago'
    },
    {
      type: 'hold',
      symbol: 'AAPL',
      name: 'Apple Inc.',
      confidence: 78,
      reason: 'Consolidating after recent gains. Wait for breakout confirmation above $190.',
      targetPrice: 190,
      currentPrice: 185.20,
      potentialGain: 2.6,
      timestamp: '1 hour ago'
    }
  ];

  const marketInsights = [
    { label: 'Market Sentiment', value: 'Bullish', icon: TrendingUp, color: 'text-green-400' },
    { label: 'Volatility Index', value: 'Moderate', icon: AlertCircle, color: 'text-yellow-400' },
    { label: 'Trade Ideas', value: '3 Active', icon: Sparkles, color: 'text-purple-400' }
  ];

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-purple-500/20 rounded-lg">
          <Sparkles className="w-5 h-5 text-purple-400" />
        </div>
        <div>
          <h2 className="text-white">AI Market Analysis</h2>
          <p className="text-slate-400 text-sm">Real-time recommendations powered by AI</p>
        </div>
      </div>

      {/* Market Insights Summary */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {marketInsights.map((insight, index) => {
          const Icon = insight.icon;
          return (
            <div key={index} className="bg-slate-900/50 rounded-lg p-3 border border-slate-700/30">
              <div className="flex items-center gap-2 mb-1">
                <Icon className={`w-4 h-4 ${insight.color}`} />
                <span className="text-slate-400 text-xs">{insight.label}</span>
              </div>
              <p className={insight.color}>{insight.value}</p>
            </div>
          );
        })}
      </div>

      {/* Recommendations List */}
      <div className="space-y-4">
        {recommendations.map((rec, index) => (
          <div
            key={index}
            className="bg-slate-900/50 rounded-xl p-4 border border-slate-700/30 hover:border-purple-500/50 transition-all"
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className={`px-3 py-1 rounded-lg text-xs uppercase ${
                  rec.type === 'buy' ? 'bg-green-500/20 text-green-400' :
                  rec.type === 'sell' ? 'bg-red-500/20 text-red-400' :
                  'bg-blue-500/20 text-blue-400'
                }`}>
                  {rec.type}
                </div>
                <div>
                  <p className="text-white">{rec.symbol}</p>
                  <p className="text-slate-400 text-sm">{rec.name}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1 mb-1">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-green-400 text-sm">{rec.confidence}% confidence</span>
                </div>
                <div className="flex items-center gap-1 text-slate-500 text-xs">
                  <Clock className="w-3 h-3" />
                  <span>{rec.timestamp}</span>
                </div>
              </div>
            </div>

            {/* Analysis */}
            <p className="text-slate-300 text-sm mb-3">{rec.reason}</p>

            {/* Metrics */}
            <div className="grid grid-cols-3 gap-3 mb-3">
              <div>
                <p className="text-slate-400 text-xs mb-1">Current Price</p>
                <p className="text-white">${rec.currentPrice}</p>
              </div>
              <div>
                <p className="text-slate-400 text-xs mb-1">Target Price</p>
                <p className="text-white">${rec.targetPrice}</p>
              </div>
              <div>
                <p className="text-slate-400 text-xs mb-1">Potential</p>
                <p className={rec.potentialGain >= 0 ? 'text-green-400' : 'text-red-400'}>
                  {rec.potentialGain >= 0 ? '+' : ''}{rec.potentialGain}%
                </p>
              </div>
            </div>

            {/* Action Button */}
            <button className={`w-full py-2 rounded-lg transition-colors ${
              rec.type === 'buy' ? 'bg-green-600 hover:bg-green-700' :
              rec.type === 'sell' ? 'bg-red-600 hover:bg-red-700' :
              'bg-blue-600 hover:bg-blue-700'
            } text-white`}>
              {rec.type === 'buy' ? 'Execute Buy Order' :
               rec.type === 'sell' ? 'Execute Sell Order' :
               'View Details'}
            </button>
          </div>
        ))}
      </div>

      {/* AI Status */}
      <div className="mt-4 p-3 bg-purple-500/10 border border-purple-500/30 rounded-lg">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
          <p className="text-purple-300 text-sm">AI is actively monitoring 247 assets and analyzing market trends</p>
        </div>
      </div>
    </div>
  );
}
