import { Users, Trophy, Calendar, TrendingUp, DollarSign, Clock, Star } from 'lucide-react';

interface Game {
  id: number;
  name: string;
  type: string;
  players: number;
  maxPlayers: number;
  prize: number;
  position?: number;
  endDate?: string;
  status?: string;
  portfolio?: number;
  entryFee?: number;
  startDate?: string;
  difficulty?: string;
}

interface GameCardProps {
  game: Game;
  isActive: boolean;
  onSelect?: (game: Game) => void;
}

export function GameCard({ game, isActive, onSelect }: GameCardProps) {
  const getDifficultyColor = (difficulty?: string) => {
    switch (difficulty) {
      case 'Beginner': return 'text-green-400 bg-green-500/20';
      case 'Intermediate': return 'text-yellow-400 bg-yellow-500/20';
      case 'Advanced': return 'text-orange-400 bg-orange-500/20';
      case 'Expert': return 'text-red-400 bg-red-500/20';
      default: return 'text-slate-400 bg-slate-500/20';
    }
  };

  const getPositionColor = (position?: number) => {
    if (!position) return 'text-slate-400';
    if (position === 1) return 'text-yellow-400';
    if (position <= 3) return 'text-blue-400';
    if (position <= 10) return 'text-green-400';
    return 'text-slate-400';
  };

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-5 border border-slate-700/50 hover:border-purple-500/50 transition-all hover:transform hover:scale-[1.02]">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-white mb-1">{game.name}</h3>
          <p className="text-slate-400 text-sm">{game.type}</p>
        </div>
        {game.difficulty && (
          <span className={`px-2 py-1 rounded-lg text-xs ${getDifficultyColor(game.difficulty)}`}>
            {game.difficulty}
          </span>
        )}
        {isActive && game.status === 'ending-soon' && (
          <span className="px-2 py-1 bg-red-500/20 text-red-400 rounded-lg text-xs flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Ending Soon
          </span>
        )}
      </div>

      {/* Stats */}
      <div className="space-y-3 mb-4">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2 text-slate-400">
            <Users className="w-4 h-4" />
            <span>Players</span>
          </div>
          <span className="text-white">{game.players}/{game.maxPlayers}</span>
        </div>

        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2 text-slate-400">
            <Trophy className="w-4 h-4" />
            <span>Prize Pool</span>
          </div>
          <span className="text-green-400">${game.prize.toLocaleString()}</span>
        </div>

        {isActive && game.position && (
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <Star className="w-4 h-4" />
              <span>Position</span>
            </div>
            <span className={getPositionColor(game.position)}>#{game.position}</span>
          </div>
        )}

        {isActive && game.portfolio && (
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <TrendingUp className="w-4 h-4" />
              <span>Portfolio</span>
            </div>
            <span className="text-purple-400">${game.portfolio.toLocaleString()}</span>
          </div>
        )}

        {!isActive && game.entryFee && (
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <DollarSign className="w-4 h-4" />
              <span>Entry Fee</span>
            </div>
            <span className="text-white">${game.entryFee}</span>
          </div>
        )}

        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2 text-slate-400">
            <Calendar className="w-4 h-4" />
            <span>{isActive ? 'Ends' : 'Starts'}</span>
          </div>
          <span className="text-white">
            {new Date(isActive ? game.endDate! : game.startDate!).toLocaleDateString('en-US', { 
              month: 'short', 
              day: 'numeric' 
            })}
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="w-full bg-slate-700/50 rounded-full h-2">
          <div 
            className="bg-gradient-to-r from-purple-500 to-blue-500 h-2 rounded-full transition-all"
            style={{ width: `${(game.players / game.maxPlayers) * 100}%` }}
          />
        </div>
      </div>

      {/* Action Button */}
      <button 
        onClick={() => onSelect && onSelect(game)}
        className={`w-full py-2 rounded-lg transition-colors ${
          isActive 
            ? 'bg-purple-600 hover:bg-purple-700 text-white' 
            : 'bg-green-600 hover:bg-green-700 text-white'
        }`}>
        {isActive ? 'View Trade Room' : 'Join Trade Room'}
      </button>
    </div>
  );
}