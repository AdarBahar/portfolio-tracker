import { TrendingUp, TrendingDown, DollarSign, Activity } from 'lucide-react';
import { useState } from 'react';
import { BuyAssetsModal } from './BuyAssetsModal';

interface PortfolioProps {
  tradeRoom: any;
}

export function Portfolio({ tradeRoom }: PortfolioProps) {
  const [showBuyModal, setShowBuyModal] = useState(false);

  const holdings = [
    {
      symbol: 'AAPL',
      name: 'Apple Inc.',
      shares: 50,
      avgPrice: 178.50,
      currentPrice: 185.20,
      value: 9260,
      change: 3.75,
      changePercent: 3.75,
      logo: 'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=100&h=100&fit=crop'
    },
    {
      symbol: 'GOOGL',
      name: 'Alphabet Inc.',
      shares: 30,
      avgPrice: 142.30,
      currentPrice: 148.90,
      value: 4467,
      change: 4.64,
      changePercent: 4.64,
      logo: 'https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?w=100&h=100&fit=crop'
    },
    {
      symbol: 'MSFT',
      name: 'Microsoft Corp.',
      shares: 25,
      avgPrice: 372.40,
      currentPrice: 368.75,
      value: 9218.75,
      change: -0.98,
      changePercent: -0.98,
      logo: 'https://images.unsplash.com/photo-1617802690992-15d93263d3a9?w=100&h=100&fit=crop'
    },
    {
      symbol: 'TSLA',
      name: 'Tesla Inc.',
      shares: 15,
      avgPrice: 245.80,
      currentPrice: 258.30,
      value: 3874.50,
      change: 5.08,
      changePercent: 5.08,
      logo: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=100&h=100&fit=crop'
    },
    {
      symbol: 'NVDA',
      name: 'NVIDIA Corp.',
      shares: 20,
      avgPrice: 485.20,
      currentPrice: 498.60,
      value: 9972,
      change: 2.76,
      changePercent: 2.76,
      logo: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?w=100&h=100&fit=crop'
    }
  ];

  const totalValue = holdings.reduce((sum, holding) => sum + holding.value, 0);
  const cashBalance = tradeRoom.portfolio - totalValue;

  return (
    <>
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-white mb-1">Your Portfolio</h2>
            <p className="text-slate-400 text-sm">Real-time positions and performance</p>
          </div>
          <div className="text-right">
            <p className="text-slate-400 text-sm">Total Value</p>
            <p className="text-white text-2xl">${tradeRoom.portfolio?.toLocaleString()}</p>
          </div>
        </div>

        {/* Portfolio Summary */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-700/30">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-4 h-4 text-blue-400" />
              <span className="text-slate-400 text-sm">Invested</span>
            </div>
            <p className="text-white">${totalValue.toLocaleString()}</p>
            <p className="text-green-400 text-xs mt-1">+$892 (2.4%)</p>
          </div>
          <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-700/30">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-4 h-4 text-green-400" />
              <span className="text-slate-400 text-sm">Cash</span>
            </div>
            <p className="text-white">${cashBalance.toLocaleString()}</p>
            <p className="text-slate-500 text-xs mt-1">Available</p>
          </div>
          <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-700/30">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-purple-400" />
              <span className="text-slate-400 text-sm">Day P&L</span>
            </div>
            <p className="text-green-400">+$1,245</p>
            <p className="text-green-400 text-xs mt-1">+5.2%</p>
          </div>
        </div>

        {/* Holdings Table */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm text-slate-400 pb-2 border-b border-slate-700/50">
            <span className="flex-1">Asset</span>
            <span className="w-24 text-right">Shares</span>
            <span className="w-24 text-right">Price</span>
            <span className="w-28 text-right">Value</span>
            <span className="w-24 text-right">Change</span>
          </div>

          {holdings.map((holding, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-3 bg-slate-900/30 rounded-lg hover:bg-slate-900/50 transition-colors"
            >
              <div className="flex items-center gap-3 flex-1">
                <img
                  src={holding.logo}
                  alt={holding.symbol}
                  className="w-10 h-10 rounded-lg object-cover"
                />
                <div>
                  <p className="text-white">{holding.symbol}</p>
                  <p className="text-slate-400 text-sm">{holding.name}</p>
                </div>
              </div>
              <span className="w-24 text-right text-white">{holding.shares}</span>
              <span className="w-24 text-right text-white">${holding.currentPrice}</span>
              <span className="w-28 text-right text-white">${holding.value.toLocaleString()}</span>
              <div className="w-24 text-right">
                <div className={`flex items-center justify-end gap-1 ${holding.changePercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {holding.changePercent >= 0 ? (
                    <TrendingUp className="w-4 h-4" />
                  ) : (
                    <TrendingDown className="w-4 h-4" />
                  )}
                  <span>{Math.abs(holding.changePercent).toFixed(2)}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3 mt-6">
          <button 
            onClick={() => setShowBuyModal(true)}
            className="py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
          >
            Buy Assets
          </button>
          <button className="py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors">
            Sell Assets
          </button>
        </div>
      </div>

      <BuyAssetsModal 
        isOpen={showBuyModal}
        onClose={() => setShowBuyModal(false)}
        tradeRoom={tradeRoom}
        availableCash={cashBalance}
      />
    </>
  );
}