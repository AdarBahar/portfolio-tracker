import { Trophy, Users, Calendar, TrendingUp, DollarSign, Clock } from 'lucide-react';

interface TradeRoomSummaryProps {
  tradeRoom: any;
}

export function TradeRoomSummary({ tradeRoom }: TradeRoomSummaryProps) {
  const summaryStats = [
    {
      icon: Trophy,
      label: 'Your Position',
      value: `#${tradeRoom.position}`,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-500/10'
    },
    {
      icon: DollarSign,
      label: 'Portfolio Value',
      value: `$${tradeRoom.portfolio?.toLocaleString()}`,
      color: 'text-green-400',
      bgColor: 'bg-green-500/10'
    },
    {
      icon: TrendingUp,
      label: 'Daily Change',
      value: '+$1,245 (5.2%)',
      color: 'text-green-400',
      bgColor: 'bg-green-500/10'
    },
    {
      icon: Users,
      label: 'Players',
      value: `${tradeRoom.players}/${tradeRoom.maxPlayers}`,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/10'
    },
    {
      icon: Trophy,
      label: 'Prize Pool',
      value: `$${tradeRoom.prize?.toLocaleString()}`,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/10'
    },
    {
      icon: Calendar,
      label: 'Time Left',
      value: '5 days 14h',
      color: 'text-orange-400',
      bgColor: 'bg-orange-500/10'
    }
  ];

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 mb-6 border border-slate-700/50">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {summaryStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className={`${stat.bgColor} rounded-xl p-4 border border-slate-700/30`}>
              <div className="flex items-center gap-2 mb-2">
                <Icon className={`w-4 h-4 ${stat.color}`} />
                <span className="text-slate-400 text-xs">{stat.label}</span>
              </div>
              <p className={`${stat.color}`}>{stat.value}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
