import { Trophy, TrendingUp, Target, Award } from 'lucide-react';

export function PlayerProfile() {
  const playerData = {
    name: 'Alex Morgan',
    username: '@alexm_trader',
    level: 42,
    globalRank: 156,
    totalGames: 87,
    wins: 52,
    winRate: 59.8,
    totalEarnings: 125430,
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&h=400&fit=crop'
  };

  const stats = [
    { label: 'Global Rank', value: `#${playerData.globalRank}`, icon: Trophy, color: 'text-yellow-400' },
    { label: 'Win Rate', value: `${playerData.winRate}%`, icon: TrendingUp, color: 'text-green-400' },
    { label: 'Total Rooms', value: playerData.totalGames, icon: Target, color: 'text-blue-400' },
    { label: 'Total Wins', value: playerData.wins, icon: Award, color: 'text-purple-400' }
  ];

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 mb-8 border border-slate-700/50">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Avatar and Basic Info */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <img
              src={playerData.avatar}
              alt={playerData.name}
              className="w-24 h-24 rounded-full object-cover ring-4 ring-purple-500/30"
            />
            <div className="absolute -bottom-2 -right-2 bg-purple-600 text-white rounded-full w-10 h-10 flex items-center justify-center">
              <span className="text-sm">{playerData.level}</span>
            </div>
          </div>
          <div>
            <h2 className="text-white mb-1">{playerData.name}</h2>
            <p className="text-slate-400 mb-2">{playerData.username}</p>
            <div className="text-green-400 flex items-center gap-1">
              <TrendingUp className="w-4 h-4" />
              <span className="text-sm">${playerData.totalEarnings.toLocaleString()} earned</span>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="bg-slate-900/50 rounded-xl p-4 border border-slate-700/30">
                <div className="flex items-center gap-2 mb-2">
                  <Icon className={`w-4 h-4 ${stat.color}`} />
                  <span className="text-slate-400 text-sm">{stat.label}</span>
                </div>
                <p className={`${stat.color} text-xl`}>{stat.value}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}