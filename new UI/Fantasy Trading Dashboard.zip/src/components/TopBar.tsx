import { useState } from 'react';
import { Bell, Mail, Settings, LogOut, User } from 'lucide-react';

export function TopBar() {
  const [showInvites, setShowInvites] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  const invites = [
    {
      id: 1,
      gameName: 'Elite Traders League',
      invitedBy: 'Sarah Chen',
      gameType: 'Stock Trading',
      prize: 15000,
      startDate: '2025-11-30',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop'
    },
    {
      id: 2,
      gameName: 'Crypto Legends',
      invitedBy: 'Mike Johnson',
      gameType: 'Cryptocurrency',
      prize: 8000,
      startDate: '2025-12-01',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop'
    },
    {
      id: 3,
      gameName: 'Pro Forex Challenge',
      invitedBy: 'Emma Wilson',
      gameType: 'Forex Trading',
      prize: 20000,
      startDate: '2025-12-02',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop'
    }
  ];

  const handleAccept = (inviteId: number) => {
    console.log('Accepted invite:', inviteId);
    // Handle accept logic
  };

  const handleDecline = (inviteId: number) => {
    console.log('Declined invite:', inviteId);
    // Handle decline logic
  };

  return (
    <div className="bg-slate-900/80 backdrop-blur-md border-b border-slate-700/50 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
              <span className="text-white">FT</span>
            </div>
            <span className="text-white hidden md:block">Fantasy Trading</span>
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center gap-3">
            {/* Messages */}
            <button className="relative p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors">
              <Mail className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full"></span>
            </button>

            {/* Game Invites */}
            <div className="relative">
              <button 
                onClick={() => setShowInvites(!showInvites)}
                className="relative p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              >
                <Bell className="w-5 h-5" />
                {invites.length > 0 && (
                  <span className="absolute top-0.5 right-0.5 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-white text-xs">
                    {invites.length}
                  </span>
                )}
              </button>

              {/* Invites Dropdown */}
              {showInvites && (
                <>
                  <div 
                    className="fixed inset-0 z-10" 
                    onClick={() => setShowInvites(false)}
                  ></div>
                  <div className="absolute right-0 mt-2 w-96 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl z-20 max-h-[80vh] overflow-hidden flex flex-col">
                    {/* Header */}
                    <div className="p-4 border-b border-slate-700">
                      <h3 className="text-white">Trade Room Invites</h3>
                      <p className="text-slate-400 text-sm">You have {invites.length} pending invitations</p>
                    </div>

                    {/* Invites List */}
                    <div className="overflow-y-auto flex-1">
                      {invites.map((invite) => (
                        <div key={invite.id} className="p-4 border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors">
                          <div className="flex items-start gap-3 mb-3">
                            <img 
                              src={invite.avatar} 
                              alt={invite.invitedBy}
                              className="w-10 h-10 rounded-full object-cover"
                            />
                            <div className="flex-1 min-w-0">
                              <p className="text-white text-sm mb-1">
                                <span className="text-purple-400">{invite.invitedBy}</span> invited you to
                              </p>
                              <p className="text-white mb-1">{invite.gameName}</p>
                              <div className="flex items-center gap-3 text-xs text-slate-400">
                                <span>{invite.gameType}</span>
                                <span>•</span>
                                <span className="text-green-400">${invite.prize.toLocaleString()}</span>
                                <span>•</span>
                                <span>{new Date(invite.startDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                              </div>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex gap-2">
                            <button 
                              onClick={() => handleAccept(invite.id)}
                              className="flex-1 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors text-sm"
                            >
                              Accept
                            </button>
                            <button 
                              onClick={() => handleDecline(invite.id)}
                              className="flex-1 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors text-sm"
                            >
                              Decline
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Footer */}
                    <div className="p-3 border-t border-slate-700 bg-slate-800/50">
                      <button className="w-full text-center text-purple-400 hover:text-purple-300 text-sm transition-colors">
                        View All Invites
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Settings */}
            <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors">
              <Settings className="w-5 h-5" />
            </button>

            {/* Profile */}
            <div className="relative">
              <button 
                onClick={() => setShowProfile(!showProfile)}
                className="flex items-center gap-2 p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              >
                <img 
                  src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop"
                  alt="Profile"
                  className="w-8 h-8 rounded-full object-cover"
                />
              </button>

              {/* Profile Dropdown */}
              {showProfile && (
                <>
                  <div 
                    className="fixed inset-0 z-10" 
                    onClick={() => setShowProfile(false)}
                  ></div>
                  <div className="absolute right-0 mt-2 w-56 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl z-20">
                    <div className="p-3 border-b border-slate-700">
                      <p className="text-white">Alex Morgan</p>
                      <p className="text-slate-400 text-sm">@alexm_trader</p>
                    </div>
                    <div className="p-2">
                      <button className="w-full flex items-center gap-3 px-3 py-2 text-slate-300 hover:bg-slate-700 rounded-lg transition-colors text-sm">
                        <User className="w-4 h-4" />
                        <span>View Profile</span>
                      </button>
                      <button className="w-full flex items-center gap-3 px-3 py-2 text-slate-300 hover:bg-slate-700 rounded-lg transition-colors text-sm">
                        <Settings className="w-4 h-4" />
                        <span>Settings</span>
                      </button>
                      <button className="w-full flex items-center gap-3 px-3 py-2 text-red-400 hover:bg-slate-700 rounded-lg transition-colors text-sm">
                        <LogOut className="w-4 h-4" />
                        <span>Logout</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}