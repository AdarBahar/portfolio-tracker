import { useState } from 'react';
import { TopBar } from './components/TopBar';
import { PlayerProfile } from './components/PlayerProfile';
import { CurrentGames } from './components/CurrentGames';
import { AvailableGames } from './components/AvailableGames';
import { SearchBar } from './components/SearchBar';
import { TradeRoomView } from './components/TradeRoomView';

export default function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTradeRoom, setSelectedTradeRoom] = useState<any>(null);

  if (selectedTradeRoom) {
    return (
      <>
        <TopBar />
        <TradeRoomView 
          tradeRoom={selectedTradeRoom} 
          onBack={() => setSelectedTradeRoom(null)} 
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <TopBar />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-white mb-2">Fantasy Trading Dashboard</h1>
          <p className="text-slate-400">Manage your trade rooms and compete with players worldwide</p>
        </div>

        {/* Search Bar */}
        <SearchBar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />

        {/* Player Profile */}
        <PlayerProfile />

        {/* Current Games */}
        <CurrentGames searchQuery={searchQuery} onSelectRoom={setSelectedTradeRoom} />

        {/* Available Games */}
        <AvailableGames searchQuery={searchQuery} />
      </div>
    </div>
  );
}