
  # Fantasy Trading Dashboard

  This is a code bundle for Fantasy Trading Dashboard. The original project is available at https://www.figma.com/design/sL14N1XYkdsQUlIoDyTmYr/Fantasy-Trading-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  